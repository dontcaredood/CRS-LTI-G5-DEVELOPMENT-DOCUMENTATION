package com.lt.constants;
/**
 * 
 * @author JEDI-03
 * Enumeration class for Notification Types
 *
 */
public enum NotificationType {
	REGISTRATION,REGISTRATION_APPROVAL,PAYMENT;
}
