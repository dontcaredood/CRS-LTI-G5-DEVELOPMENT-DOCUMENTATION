package com.lt.exceptions;

public class CRSException {

}
