package com.lt.controller;

import javax.ws.rs.core.MediaType;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.lt.bean.Customer;

@RestController
@RequestMapping("/Customer")
public class CustomerController {
	
	
	@RequestMapping(produces = MediaType.APPLICATION_JSON, 
		    method = RequestMethod.GET,
		    value = "/details")
		@ResponseBody
	 public Customer details(){
		
		Customer c1=new Customer();
		//We need to call the service layer over here and set all the values
		c1.setCustomerId(101);
		c1.setCustomerName("amit");
		c1.setCustomerAddress("delhi");
			
		
		return c1;	
	
	}
}
