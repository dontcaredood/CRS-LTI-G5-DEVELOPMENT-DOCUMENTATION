package com.lt.bean;

public class Catalouge {
	private Course course;
	private int courseCatalougeId;
	
	public Course getCourse() {
		return course;
	}
	public void setCourse(Course course) {
		this.course = course;
	}
	public int getCourseCatalougeId() {
		return courseCatalougeId;
	}
	public void setCourseCatalougeId(int courseCatalougeId) {
		this.courseCatalougeId = courseCatalougeId;
	}
	
	}
