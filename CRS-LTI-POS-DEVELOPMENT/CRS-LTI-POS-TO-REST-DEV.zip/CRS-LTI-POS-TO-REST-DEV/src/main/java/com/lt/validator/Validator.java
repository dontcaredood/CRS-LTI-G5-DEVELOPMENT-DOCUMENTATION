package com.lt.validator;

public class Validator {

}
