package com.lt.application;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CrsRestProjectPracticeApplicationTests {

	@Test
	void contextLoads() {
	}

}
